library("ggplot2")
library("ggrepel")
library("dplyr")
library("patchwork")
library("vegan")
library("ggpubr")
##########Figure 5
##########Correlation analysis
setwd("./Codes/Figure5/")
data<-read.csv("component pairing.csv")


formula<-y ~ x
p<-ggplot(data,aes(Gene1,Lexicon1,colour = Latitude))+
  geom_point(size=5,alpha=0.8)+
  geom_smooth(color="black",method="lm",se=T, formula = formula)+
  labs(x="Northern genetic component",y="Northern language component")+theme_bw()+  
  theme(panel.grid = element_blank())
p1<-p+scale_color_gradient("Latitude", high = "#D8784E",low = "#2D6CB5")
p2<-p1+geom_text(aes(label = Province), size = 4,color = "black",vjust = -2)
p2

cor_result<-cor.test(data$Gene1,data$Lexicon1,alternative="two.sided",method="pearson",exact = F)
cor_result


##########mantel and partial mantel
###In linguistic data, we merged Hong Kong and Macau samples into Guangdong province to facilitate comparison
###We replicate one Tianjin sample to fit the calculation for provincial mean values
dataset<-read.csv("lexical inventory for genetic pairing.csv")
ham_data <- dataset[,c(-2:-3)]
ham_data <- rbind(ham_data,subset(ham_data,ham_data[,1] == "Tianjin"))

geo_data <- dataset[,3:5]
geo_data <- rbind(geo_data,subset(geo_data,geo_data[,1] == "Tianjin"))

###great circle distances
two_group_geo <- function(k,df){
  x_rows <- df[, 1] == k[1]
  x <- df[x_rows, -1]
  y_rows <- df[, 1] == k[2]
  y <- df[y_rows, -1]
  x<-apply(x,2,as.numeric)
  y<-apply(y,2,as.numeric)
  mat<-matrix(data<-NA,nrow = nrow(x),ncol = nrow(y))
  for(i in 1:nrow(x)){
    for(j in 1:nrow(y)){
      dist<-distHaversine(x[i,],y[j,])
      mat[i,j]<-dist
    }
  }
  sum<-sum(mat)/nrow(x)/nrow(y)
  print(sum)
  return(sum)
}
pairwise_geo <- function(df){
  group_names <- unique(df[,1])
  # Generate all pairwise combinations of group names
  num_list <- combn(group_names, 2, simplify = FALSE)
  distances <- lapply(num_list,function(i)two_group_geo(i, df))
  distances_var <- unlist(distances)
  geo_mat<-matrix(0,nrow = length(group_names),ncol = length(group_names))
  geo_mat[lower.tri(geo_mat)]<-distances_var
  geo_mat<-t(geo_mat)
  geo_mat[lower.tri(geo_mat)]<-distances_var
  colnames(geo_mat) <- group_names
  rownames(geo_mat) <- group_names
  return(geo_mat)
}
geo_matrix <- pairwise_geo(geo_data)
geo_dist_log<-log10(geo_matrix/1000 + 1)

###hamming distances

hamming_distance <- function(x, y) {
  # Remove missing values from both vectors
  x1 <- x[complete.cases(x, y)]
  y1 <- y[complete.cases(x, y)]
  
  # Check if the sequences have equal length
  if(length(x1) != length(y1)) {
    stop("Error: Sequences need to have equal length")
  }
  
  # Calculate the Hamming distance
  ave_ham <- sum(x1 != y1)/length(x1)
  return(ave_ham)
}

two_group_hamming<-function(k, df){
  x_rows <- df[, 1] == k[1]
  x <- df[x_rows, -1]
  y_rows <- df[, 1] == k[2]
  y <- df[y_rows, -1]
  x<-apply(x,2,as.numeric)
  y<-apply(y,2,as.numeric)
  mat<-matrix(data<-NA,nrow = nrow(x),ncol = nrow(y))
  for(i in 1:nrow(x)){
    for(j in 1:nrow(y)){
      dist<-hamming_distance(x[i,],y[j,])
      mat[i,j]<-dist
    }
  }
  sum<-sum(mat)/nrow(x)/nrow(y)
  print(sum)
  return(sum)
}



pairwise_hamming <- function(df){
  group_names <- unique(df[,1])
  
  # Generate all pairwise combinations of group names
  num_list <- combn(group_names, 2, simplify = FALSE)
  distances <- lapply(num_list,function(i)two_group_hamming(i, df))
  distances_var <- unlist(distances)
  ham_mat<-matrix(0,nrow = length(group_names),ncol = length(group_names))
  ham_mat[lower.tri(ham_mat)]<-distances_var
  ham_mat<-t(ham_mat)
  ham_mat[lower.tri(ham_mat)]<-distances_var
  colnames(ham_mat) <- group_names
  rownames(ham_mat) <- group_names
  return(ham_mat)
}
ham <- pairwise_hamming(ham_data)


###read genetic distance matrix
gene <- read.csv("gene.mat.csv")
gene <- gene[,-1]

geo <- geo_dist_log

###mantel

mantel(ham, gene, method <- "spearman", permutation = 10000)
mantel.partial(ham, gene, geo, method <- "spearman", permutation = 10000)

mantel(ham, geo, method = "spearman",permutation = 10000)
mantel.partial(ham, geo, gene, method <- "spearman", permutation = 10000)

mantel(gene, geo, method = "spearman",permutation = 10000)
mantel.partial(gene, geo, ham, method <- "spearman", permutation = 10000)

