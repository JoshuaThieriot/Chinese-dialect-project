library("PCAviz")
library("cowplot")
library("impute")
library("ggplot2")
library("magrittr")
library("vegan")
library("geosphere")
library("raster")
library("sf")
library("sp")
library("gstat")
library("rgdal")
library("dismo")
library("rgeos")
library("ggspatial")
library("tidyverse")

##########Figure 1
##########PCA

###Read file
setwd("D:/BrandNewDay/Codes-for-paper/Files/Dialect admixture/Codes/Figure1")
dataset<-read.csv("TableS5. Lexical inventory.csv")

raw <- dataset[,c(-1:-5)]
raw <- apply(raw,2,as.numeric)

###Impute

result_impute <- impute.knn(raw ,k = 10, rowmax = 0.5, colmax = 0.8, maxp = 1500, rng.seed=362436069)
impute_pc<-result_impute$data

###PCA and save PCs

result<-prcomp(impute_pc,scale.=F)

dialect <- as.factor(dataset$Dialect_group)
coords <- apply(dataset[,4:5],2,as.numeric)
plotset <- data.frame(dialect, coords)
colnames(plotset) <- c("dialect", "longitude", "latitude")

vizdata <- pcaviz(result,dat = plotset)
pcdata<-vizdata$data
save(pcdata, file = "pc.RData")

###PCA plot
#screeplot(result, npcs = 10, type = "lines")

my_colors<-c("#BFA06E","#4AA54A","#66CDAA","#0073C2","#EFC000",
             "#9590FF","#B65F81","#83d0e8","#E66F51","#FFD9D9")

plot(vizdata, coords = c("PC1","PC2"),colors = my_colors,draw.points = T,
     geom.point.summary.params = list(shape = 19,stroke = 1,size = 15,
                                      show.legend = FALSE,alpha = 0.8))

##########Linear regression test and plot of PCs and geography

plot(vizdata, coords = c("PC1","latitude"),colors = my_colors,draw.points = T,
     geom.point.summary.params = list(shape = 19,stroke = 1,size = 15,alpha = 0.8))
cor_result_1<-cor.test(pcdata$latitude,pcdata$PC1,alternative="two.sided",method="pearson",exact = F)
cor_result_1

plot(vizdata, coords = c("PC1","longitude"),colors = my_colors,draw.points = T,
     geom.point.summary.params = list(shape = 19,stroke = 1,size = 15,alpha = 0.8))
cor_result_2<-cor.test(pcdata$longitude,pcdata$PC1,alternative="two.sided",method="pearson",exact = F)
cor_result_2

###Linear regression of median PCs and geography of dialect groups
load("pc.RData")
group_pc <- split(pcdata, pcdata$dialect)
median_pc <- sapply(group_pc,function(i){
  x <- i[,2:4]
  mean <- apply(x,2,mean)
  return(mean)
})
median_pc <- t(median_pc)
median_pc <- as.data.frame(median_pc) 
median_pc <- cbind(Dialect = row.names(median_pc), median_pc)
  

ggplot(median_pc,aes(x = PC1,y = latitude)) + geom_point(mapping = aes(color = Dialect))+ theme_bw() + 
  geom_smooth(method = "lm", color = "black")+  
  theme(panel.grid = element_blank())
cor_result_3<-cor.test(median_pc$latitude,median_pc$PC1,alternative="two.sided",method="pearson",exact = F)
cor_result_3

###Procrustes analysis of PC12 and geography
proc.result <- protest(pcdata[,4:5],pcdata[,2:3], scores = "sites", permutations = how(nperm = 10000))
proc.result

###Mantel analysis of linguistic and geography (926 samples)
###Geographic distance
geo_dist<-matrix(data = NA, nrow = 926, ncol = 926)

for(i in 1:nrow(coords)){
  for( j in 1:nrow(coords)){
    geo_dist[i,j]<-distHaversine(coords[i,],coords[j,])
  }
}

geo_dist_log<-log(geo_dist/1000 + 1)

###Hamming distance
hamming_distance <- function(x, y) {
  # Remove missing values from both vectors
  x1 <- x[complete.cases(x, y)]
  y1 <- y[complete.cases(x, y)]
  
  # Calculate the Hamming distance
  ave_ham <- sum(x1 != y1)/length(x1)
  print(ave_ham)
}
hamming_matrix <- matrix(data = NA, ncol = 926, nrow = 926)

for(i in 1:926){
  for(j in 1:926){
    hamming_matrix[i,j] <- hamming_distance(raw[i,],raw[j,])
  }
}

###Mantel
mantel(hamming_matrix, geo_dist_log, method = "spearman", permutations = 10000)

##########Sample map plot
china_map <- st_read("bou2_4l.shp")
Ps_Mercator <- st_crs("EPSG:3857")
china <- st_transform(china_map, crs=Ps_Mercator)


base_map <- ggplot(china)+geom_sf(fill = NA)+theme_bw()

###transform data points
load("pc.RData")
df <- pcdata[,1:4]
colnames(df) <- c("Dialect", "Longitude", "Latitude","PC1")

df_trans <- st_as_sf(df, coords = c(x = "Longitude", y = "Latitude"))
WGS84<- CRS("+proj=longlat +datum=WGS84 +no_defs")
st_crs(df_trans) <- WGS84
df_trans <- st_transform(df_trans, crs = Ps_Mercator)

###retrieve trasnformed coordinates
Merc_df <-st_coordinates(df_trans)
Merc_df <- data.frame(Dialect = df$Dialect, PC1 = df$PC1, Merc_df)

###plotting
my_colors<-c("#BFA06E","#4AA54A","#66CDAA","#0073C2","#EFC000",
             "#9590FF","#B65F81","#83d0e8","#E66F51","#FFD9D9")

sample_map <- base_map + geom_point(data = Merc_df, aes(x = X, y = Y, color = Dialect), size = 1, alpha = 0.8)+
  scale_color_manual(values = my_colors)+
  annotation_north_arrow(location="tl",which_north="false",style=north_arrow_fancy_orienteering)+
  annotation_scale(location = "bl")+
  xlab("Longitute") +
  ylab("Latitude")

#########PC1 interpolation

dsp <- SpatialPoints(st_coordinates(df_trans),CRS("+proj=merc"))
dsp <- SpatialPointsDataFrame(dsp,pcdata)
###read China map
bound <- rgdal::readOGR("bou2_4p.shp")
bound1 <- spTransform(bound, CRS("+proj=merc"))
plot(bound1)
###visualize pc1 on China map
max(pcdata$PC1)###6.993098
min(pcdata$PC1)###-6.818153

cuts<-c(-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7)

blues <- colorRampPalette(c("#0073C2","#EFC000"))(14)
pols <- list("sp.polygons",bound1, fill = "lightgray")
spplot(dsp,"PC1", cuts=cuts, col.regions=blues, sp.layout=pols, pch=20, cex=2)

###create voronoi polygons
v <- voronoi(dsp)
bound2<-aggregate(bound1)###lower resolution

###interscept two layers
v1<-intersect(v,bound2)
spplot(v1, "PC1", col.regions=rev(get_col_regions()))

###rasterize
blank_raster<-raster(nrow=1200,ncol=1200,extent(bound1))
values(blank_raster)<-1
bound_raster<-rasterize(bound1,blank_raster)
plot(bound_raster,main=paste("Res: ",1200,"*",1200))
plot(bound1, add = T)

vr <- rasterize(v1,bound_raster,"PC1")
plot(vr)

###inverse distance weighted interpolation
gs <- gstat(formula=dsp$PC1~1, locations=dsp, nmax = 15, nmin = 5)
idw <- interpolate(bound_raster, gs)
idwmask<-mask(idw,vr)

###tansform to df format
idwmask_df <- as.data.frame(idwmask, xy = TRUE) %>% na.omit()
colnames(idwmask_df)<-c("x","y","PC1")

cols <- colorRampPalette(c("#B65F81","#EFC000"))(14)

p1 <- ggplot() + geom_tile(data = idwmask_df, aes(x = x, y = y, fill = PC1))+theme_bw()+
  scale_fill_gradientn(colours = cols)+
  labs(x ='Longitude',y="Latitude")

###base outline map
china_map <- st_read("bou2_4l.shp")
Ps_Mercator <- st_crs("EPSG:3857")
china <- st_transform(china_map, crs=Ps_Mercator)


p2 <- p1 + geom_sf(data = china,fill = NA)+theme_bw()
p2
###add rivers
rivers<-st_read("river-1j.shp")

rivers_need<-filter(rivers,rivers$名称%in%c("长江","黄河","淮河"))
rivers_need<-st_transform(rivers_need,crs = Ps_Mercator)

p3<-p2+geom_sf(data=rivers_need,aes(fill=NULL),col="#466AB2", lwd = 0.5)
p3
