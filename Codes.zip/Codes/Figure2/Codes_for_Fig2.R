library(pcadapt)
library(qvalue)
library(ggplot2)
library(ggrepel)

##########Figure 2
##########Manhattan plot

setwd("D://BrandNewDay/Codes-for-paper/Files/Dialect admixture/Codes/Figure2/")

dataset <- read.csv("TableS5. Lexical inventory.csv")
raw <- dataset[,-1:-5]

###determine the number of PCs to retain
file <- read.pcadapt(raw, type = "lfmm")
x <- pcadapt(input = file, K = 20,ploidy = 1)
plot(x, option = "screeplot")###choose K=3

###data cleaning
x <- pcadapt(input = file, K = 3,ploidy = 1, min.maf = 0.05)
logP<- -log10(x$pvalues)

###Q-value
qval <- qvalue(x$pvalues)$qvalues
alpha <- 0.001
outliers <- which(qval < alpha)0

P_df<-data.frame(id = 1:1018, logP)
outlier_df<-subset(P_df, id %in% outliers)
p1<-ggplot(data = P_df, aes(x = id, y = logP))+
  geom_point(cex = 3, col = "grey", pch = 19)+theme_classic()+
  geom_hline(aes(yintercept=min(outlier_df$logP)))+
  geom_text_repel( data= outlier_df, aes(label=id), size=5)+
  labs(x = "Lexical trait id", y = "-log(P-values)")+
  scale_x_continuous(expand = c(0, 0))+
  scale_y_continuous(expand = c(0, 0), limits = c(0,25))

p2<-p1+geom_point(data = outlier_df, aes(x = id, y= logP), col = "#EFC000", cex = 4)
p2



