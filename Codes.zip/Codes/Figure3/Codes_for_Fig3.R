library(tess3r)
library(maptools)
library(maps)
library(sf)
library(raster)
library(ggplot2)
library(tidyverse)

##########Figure 3
###R4.1.1

setwd("D:/BrandNewDay/Codes-for-paper/Files/Dialect admixture/Codes/Figure3/")

data<-read.csv("lexical inventory-multistate.csv")
save(data,file = "data.RData")

###R4.2.2
load("data.RData")

###transform data
datatess3<-tess2tess3(data, FORMAT = 1, extra.column = 3,diploid = F,TESS = T)

obj <- tess3(X = datatess3$X, coord = datatess3$coord,
                 K = 1:6, ploidy = 1, openMP.core.num = 4)

###prepare a tess3Q variable (not used,just to create a tess3Q object that can be used in tess3r )
q.matrix <- qmatrix(obj, K = 6)

qmatrix<-as.matrix(q.matrix)

###read structure data to substitute the q-matrix
struc<-read.table("K6i.outfile")
struc<-as.matrix(struc[,6:11])
qmatrix<-as.matrix(q.matrix)

qmatrix[,1:6]<-struc

###Prepare colors

my.colors<- c("#83d0e8","#E66F51","#FFD9D9","#EFC000","#0073C2","#66CDAA")
my.palette <- CreatePalette(my.colors, 9)

###Read a base map of China and convert to merc
china_map <- st_read("bou2_4p.shp")

Ps_Mercator <- st_crs("EPSG:3857")
china_merc <- st_transform(china_map, crs=Ps_Mercator)
merc_base <- ggplot(china_merc)+geom_sf(fill = NA, lwd = 1)+theme_bw()


###Convert coordinates to merc
coords <- data.frame(datatess3$coord)
colnames(coords) <- c("longitude","latitude")
df_trans <- st_as_sf(coords, coords = c(x = "longitude", y = "latitude"))
WGS84<- CRS("+proj=longlat +datum=WGS84 +no_defs")
st_crs(df_trans) <- WGS84
df_trans <- st_transform(df_trans, crs = Ps_Mercator)
Merc_df <-st_coordinates(df_trans)

###Interpolation
interpolation_plot <- ggtess3Q(qmatrix, Merc_df, map.polygon = china_merc,
               interpolation.model = FieldsTpsModel(),
               resolution = c(1000, 1000),col.palette = my.palette)
###add outline
china_map_l <- st_read("bou2_4l.shp")
china_map_l <- st_transform(china_map_l, crs=Ps_Mercator)
p2 <- interpolation_plot  + geom_sf(data = china_map_l)+
  xlab("Longitute") +
  ylab("Latitude") + 
  theme_bw()


###add rivers
rivers<-sf::read_sf("river-1j.shp")

rivers_need<-filter(rivers,rivers$名称%in%c("长江","黄河","淮河"))
rivers_need<-st_transform(rivers_need,crs = Ps_Mercator)

p3<-p2+geom_sf(data=rivers_need,aes(fill=NULL),col="#466AB2", lwd = 0.5)
p3
