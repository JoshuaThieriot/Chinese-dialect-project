clearvars;
close all;

%%FeatureData, GroupInd
PopNum = max(GroupInd);
method = 'Jaccard';

for i = 1:PopNum
    acc = FeatureData(GroupInd==i,:);
    n = 1:PopNum;
    n(i) = [];
    temp = nchoosek(n,2);
    for k = 1:size(temp,1)
        aca = FeatureData(GroupInd==temp(k,1),:);
        acb = FeatureData(GroupInd==temp(k,2),:);
        [B,T,f3(i,k),normed_f3(i,k),z(i,k)] = patterson_f3(acc, aca, acb);
    end    
end
f3_prod_sign = sum(f3 < 0 ,2); 


LangName = {'NM','JHM','Wu','SWM','Gan','Xiang','Hakka','Pingtu','Min','Yue'}
scaffold_pop_names = {'NM','Wu','Min','Yue','Xiang'}



%%total feature without any bootstrap
mean_f2 = zeros(PopNum,PopNum);
h = zeros(PopNum,1);
for i =1:PopNum
    aca = FeatureData(GroupInd==i,:);
    h(i) = mean(h_hat(aca));
    h_1(i) = mean(pdist(aca,method));  
    for j = (i+1):PopNum
        acb = FeatureData(GroupInd==j,:);
        [~, mean_f2(i,j)] = patterson_f2(aca, acb);
        mean_f2_1(i,j) = mean(mean(pdist2(aca,acb,method))); 
        mean_f2_1(j,i) = mean_f2_1(i,j);
        mean_f2(j,i) = mean_f2(i,j);
    end
end
pop_data.f2 = mean_f2;
pop_data.h = h;
pop_data.pop_names = LangName';
options.drift_units = 1;
Phylotree = MixMapper(pop_data,scaffold_pop_names);
view(Phylotree);
clear h mean_f2

%%bootstrap
pop_data_reps = struct;
MaxBootstrap = 500;
for k = 1:MaxBootstrap  %%bootstrap number
    BSind = randi(size(FeatureData,2),1,size(FeatureData,2));
    mean_f2 = zeros(PopNum,PopNum);
    h = zeros(PopNum,1);
    for i =1:PopNum
        aca = FeatureData(GroupInd==i,BSind);
        h(i) = mean(h_hat(aca));
        h_1(i) = mean(pdist(aca,method));  
        for j = i+1:PopNum
            acb = FeatureData(GroupInd==j,BSind);
            [~, mean_f2(i,j)] = patterson_f2(aca, acb);
             mean_f2_1(i,j) = mean(mean(pdist2(aca,acb,method))); 
            mean_f2(j,i) = mean_f2(i,j);
            mean_f2_1(j,i) = mean_f2_1(i,j);
        end
    end
    pop_data_reps(k).f2 = mean_f2;
    pop_data_reps(k).h = h;
    pop_data_reps(k).pop_names = LangName';
end

options.drift_units = 1;
options.verbose = 0; %%1/0
options.test_2v3 = 0;  %%1/0
options.branch_sets = 1; %%1/0
options.outfile = '2wave.txt';
options.no_opt3way = 0;

for c = setdiff(LangName,scaffold_pop_names)
    [trees,fits] = MixMapper(pop_data_reps(1:MaxBootstrap),scaffold_pop_names,char(c),'',options);
end




options.outfile = '3wave.txt';
[trees,fits] = MixMapper(pop_data_reps(1:MaxBootstrap),scaffold_pop_names,'Gan','Hakka',options);
