% %     Unbiased estimator for F3(C; A, B), the three-population test for
% %     admixture in population C.
% % 
% %     Parameters
% %     ----------
% %     acc : array_like, int, shape (n_variants, m)
% %         Allele counts for the test population (C).
% %     aca : array_like, int, shape (n_variants, m)
% %         Allele counts for the first source population (A).
% %     acb : array_like, int, shape (n_variants, m)
% %         Allele counts for the second source population (B).
% % 
% %     Returns
% %     -------
% %     T : ndarray, float, shape (n_variants,)
% %         Un-normalized f3 estimates per variant.
% %     B : ndarray, float, shape (n_variants,)
% %         Estimates for heterozygosity in population C.
% % 
% %     Notes
% %     -----
% %     See Patterson (2012), main text and Appendix A.
% % 
% %     For un-normalized f3 statistics, ignore the `B` return value.
% % 
% %     To compute the f3* statistic, which is normalized by heterozygosity in
% %     population C to remove numerical dependence on the allele frequency
% %     spectrum, compute ``np.sum(T) / np.sum(B)``.

function [B,T,f3,normed_f3,z] = patterson_f3(acc, aca, acb)
[freq0_c, freq1_c, markerNum_c] = countfreq(acc);
[freq0_a, freq1_a, markerNum_a] = countfreq(aca);
[freq0_b, freq1_b, markerNum_b] = countfreq(acb);

B = 2 * h_hat(acc);  %%����ѧ�ϵ��Ӻ϶� %%vector
T = (freq0_c - freq0_a).*(freq0_c - freq0_b) - h_hat(acc)./markerNum_c;  %%vector
% # calculate overall value of statistic
f3 = mean(T);  %% overall mean value; int
normed_f3 = sum(T) / sum(B);  %% overall normed value; int

z = normed_f3/std(T);
z = z*sqrt(length(T));
end 