library("PCAviz")
library("cowplot")
library("impute")
library("ggplot2")
library("magrittr")
library("vegan")
library("tidyverse")

##########Figure 1
##########PCA

###Read file
###This table is available in Supplementary Table 2
setwd("./Codes/Figure1")
dataset<-read.csv("Lexical inventory.csv")

raw <- dataset[,c(-1:-5)]
raw <- apply(raw,2,as.numeric)

###Impute missing values

result_impute <- impute.knn(raw ,k = 10, rowmax = 0.5, colmax = 0.8, maxp = 1500, rng.seed=362436069)
impute_pc<-result_impute$data

###PCA and save PCs

result<-prcomp(impute_pc,scale.= F)

dialect <- as.factor(dataset$Dialect_group)
coords <- apply(dataset[,4:5],2,as.numeric)
plotset <- data.frame(dialect, coords)
colnames(plotset) <- c("dialect", "longitude", "latitude")

vizdata <- pcaviz(result,dat = plotset)
pcdata<-vizdata$data
save(pcdata, file = "pc.RData")

###PCA plot
#screeplot(result, npcs = 10, type = "lines")

my_colors<-c("#BFA06E","#4AA54A","#66CDAA","#0073C2","#EFC000",
             "#9590FF","#B65F81","#83d0e8","#E66F51","#FFD9D9")

plot(vizdata, coords = c("PC1","PC2"),colors = my_colors,draw.points = T,
     geom.point.summary.params = list(shape = 19,stroke = 1,size = 15,
                                      show.legend = FALSE,alpha = 0.8))

##########Correlation analysis of PCs and geographic coordinates

plot(vizdata, coords = c("PC1","latitude"),colors = my_colors,draw.points = T,
     geom.point.summary.params = list(shape = 19,stroke = 1,size = 15,alpha = 0.8))
cor_result_1<-cor.test(pcdata$latitude,pcdata$PC1,alternative="two.sided",method="spearman",exact = F)
cor_result_1

plot(vizdata, coords = c("PC1","longitude"),colors = my_colors,draw.points = T,
     geom.point.summary.params = list(shape = 19,stroke = 1,size = 15,alpha = 0.8))
cor_result_2<-cor.test(pcdata$longitude,pcdata$PC1,alternative="two.sided",method="spearman",exact = F)
cor_result_2

###Correlation analysis of median PCs and geographic coordinates (group-wise)
load("pc.RData")
group_pc <- split(pcdata, pcdata$dialect)
median_pc <- sapply(group_pc,function(i){
  x <- i[,2:4]
  median <- apply(x,2,median)
  return(median)
})
median_pc <- t(median_pc)
median_pc <- as.data.frame(median_pc) 
median_pc <- cbind(Dialect = row.names(median_pc), median_pc)
  

ggplot(median_pc,aes(x = PC1,y = latitude)) + geom_point(mapping = aes(color = Dialect))+ theme_bw() + 
  geom_smooth(method = "lm", color = "black")+  
  theme(panel.grid = element_blank())
cor_result_3<-cor.test(median_pc$latitude,median_pc$PC1,alternative="two.sided",method="spearman",exact = F)
cor_result_3

###Procrustes analysis of PC12 and geographic coordinates
proc.result <- protest(pcdata[,4:5],pcdata[,2:3], scores = "sites", permutations = how(nperm = 100000))
proc.result

###Mantel analysis of linguistic and geography (926 samples)
###Geographic distance
geo_dist<-matrix(data = NA, nrow = 926, ncol = 926)

for(i in 1:nrow(coords)){
  for( j in 1:nrow(coords)){
    geo_dist[i,j]<-distHaversine(coords[i,],coords[j,])
  }
}

geo_dist_log<-log10(geo_dist/1000 + 1)

###Hamming distance
hamming_distance <- function(x, y) {
  # Remove missing values from both vectors
  x1 <- x[complete.cases(x, y)]
  y1 <- y[complete.cases(x, y)]
  
  # Calculate the Hamming distance
  ave_ham <- sum(x1 != y1)/length(x1)
  print(ave_ham)
}
hamming_matrix <- matrix(data = NA, ncol = 926, nrow = 926)

for(i in 1:926){
  for(j in 1:926){
    hamming_matrix[i,j] <- hamming_distance(raw[i,],raw[j,])
  }
}

###Mantel
mantel(hamming_matrix, geo_dist_log, method = "spearman", permutations = 10000)

